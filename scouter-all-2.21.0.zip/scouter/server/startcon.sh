#!/usr/bin/env bash
java -Xmx512m -cp scouter-server-boot.jar scouter.boot.Boot ./lib -console

